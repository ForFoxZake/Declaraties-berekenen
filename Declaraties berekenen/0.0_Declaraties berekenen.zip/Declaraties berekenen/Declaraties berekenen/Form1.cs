﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Declaraties_berekenen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Begin Uren toevoegen in combobox
            for (int uren = 0; uren <= 23; uren++)
            {
                cb_BeginUur.Items.Add(uren);
            }

            //Begin Minuten toevoegen in combobox
            for (int minuten = 0; minuten <= 60; minuten++)
            {
                cb_BeginMinuten.Items.Add(minuten);
            }


            //Eind Uren Toevoegen in combobox
            for (int uren = 0; uren <= 23; uren++)
            {
                cb_EindUur.Items.Add(uren);
            }
            //Eind minuten Toevoegen in combobox
            for (int minuten = 0; minuten <= 60; minuten++)
            {
                cb_EindMinuten.Items.Add(minuten);
            }
        }//form1

        private void btn_bereken_Click(object sender, EventArgs e)
        {
            //Begin uren en minuten aan elkaar plakken
            int begin_uren = Convert.ToInt32(cb_BeginUur.SelectedItem);
            int begin_minuten= Convert.ToInt32(cb_BeginMinuten.SelectedItem);
            TimeSpan begin_tijd = TimeSpan.FromHours(begin_uren) + TimeSpan.FromMinutes(begin_minuten);
            string fromTimeString_begintijd = begin_tijd.ToString("hh':'mm");
            //MessageBox.Show("Begin tijd:" + fromTimeString_begintijd); //WERKT!!!

            //Eind uren en minuten aan elkaar plakken
            int eind_uren = Convert.ToInt32(cb_EindUur.SelectedItem);
            int eind_minuten = Convert.ToInt32(cb_EindMinuten.SelectedItem);
            TimeSpan eind_tijd = TimeSpan.FromHours(eind_uren) + TimeSpan.FromMinutes(eind_minuten);
            string fromTimeString_eindtijd = eind_tijd.ToString("hh':'mm");
            //MessageBox.Show("Eind tijd:" + fromTimeString_eindtijd); //WERKT!!!
            

            //Verschil Begin en Einduur berekenen
            TimeSpan verschil = eind_tijd - begin_tijd;
            tb_werkuren.Text = Convert.ToString(String.Format("{0}:{1}",verschil.Hours ,verschil.Minutes));

            //
            int dagbedrag = Convert.ToInt32(tb_werkuren.Text) * Convert.ToInt32(tb_EuroPerUur.Text);
        }//btn_bereken_Click
    }
}
