﻿namespace Declaraties_berekenen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_werkdag = new System.Windows.Forms.ComboBox();
            this.lbl_BeginUur = new System.Windows.Forms.Label();
            this.lbl_EindUue = new System.Windows.Forms.Label();
            this.tb_werkuren = new System.Windows.Forms.TextBox();
            this.lbl_urenGewerkt = new System.Windows.Forms.Label();
            this.tb_EuroPerUur = new System.Windows.Forms.TextBox();
            this.btn_bereken = new System.Windows.Forms.Button();
            this.lbl_DagBedrag = new System.Windows.Forms.Label();
            this.tb_dagbedrag = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.gb_gegevens = new System.Windows.Forms.GroupBox();
            this.lbl_EuroPerUur = new System.Windows.Forms.Label();
            this.gb_WerkDag = new System.Windows.Forms.GroupBox();
            this.cb_BeginUur = new System.Windows.Forms.ComboBox();
            this.cb_BeginMinuten = new System.Windows.Forms.ComboBox();
            this.cb_EindUur = new System.Windows.Forms.ComboBox();
            this.cb_EindMinuten = new System.Windows.Forms.ComboBox();
            this.gb_gegevens.SuspendLayout();
            this.gb_WerkDag.SuspendLayout();
            this.SuspendLayout();
            // 
            // cb_werkdag
            // 
            this.cb_werkdag.BackColor = System.Drawing.SystemColors.Window;
            this.cb_werkdag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_werkdag.FormattingEnabled = true;
            this.cb_werkdag.Items.AddRange(new object[] {
            "Maandag",
            "Dinsdag",
            "Woensdag",
            "Donderdag",
            "Vrijdag",
            "Zaterdag",
            "Zondag"});
            this.cb_werkdag.Location = new System.Drawing.Point(6, 54);
            this.cb_werkdag.Name = "cb_werkdag";
            this.cb_werkdag.Size = new System.Drawing.Size(121, 21);
            this.cb_werkdag.TabIndex = 22;
            this.cb_werkdag.UseWaitCursor = true;
            // 
            // lbl_BeginUur
            // 
            this.lbl_BeginUur.AutoSize = true;
            this.lbl_BeginUur.Location = new System.Drawing.Point(4, 33);
            this.lbl_BeginUur.Name = "lbl_BeginUur";
            this.lbl_BeginUur.Size = new System.Drawing.Size(54, 13);
            this.lbl_BeginUur.TabIndex = 24;
            this.lbl_BeginUur.Text = "Begin Uur";
            // 
            // lbl_EindUue
            // 
            this.lbl_EindUue.AutoSize = true;
            this.lbl_EindUue.Location = new System.Drawing.Point(10, 73);
            this.lbl_EindUue.Name = "lbl_EindUue";
            this.lbl_EindUue.Size = new System.Drawing.Size(48, 13);
            this.lbl_EindUue.TabIndex = 25;
            this.lbl_EindUue.Text = "Eind Uur";
            // 
            // tb_werkuren
            // 
            this.tb_werkuren.Location = new System.Drawing.Point(144, 155);
            this.tb_werkuren.Name = "tb_werkuren";
            this.tb_werkuren.ReadOnly = true;
            this.tb_werkuren.Size = new System.Drawing.Size(100, 20);
            this.tb_werkuren.TabIndex = 26;
            // 
            // lbl_urenGewerkt
            // 
            this.lbl_urenGewerkt.AutoSize = true;
            this.lbl_urenGewerkt.Location = new System.Drawing.Point(141, 139);
            this.lbl_urenGewerkt.Name = "lbl_urenGewerkt";
            this.lbl_urenGewerkt.Size = new System.Drawing.Size(96, 13);
            this.lbl_urenGewerkt.TabIndex = 27;
            this.lbl_urenGewerkt.Text = "Aantal uur gewerkt";
            // 
            // tb_EuroPerUur
            // 
            this.tb_EuroPerUur.Location = new System.Drawing.Point(7, 128);
            this.tb_EuroPerUur.Name = "tb_EuroPerUur";
            this.tb_EuroPerUur.Size = new System.Drawing.Size(100, 20);
            this.tb_EuroPerUur.TabIndex = 28;
            // 
            // btn_bereken
            // 
            this.btn_bereken.Location = new System.Drawing.Point(7, 154);
            this.btn_bereken.Name = "btn_bereken";
            this.btn_bereken.Size = new System.Drawing.Size(75, 23);
            this.btn_bereken.TabIndex = 30;
            this.btn_bereken.Text = "Bereken ";
            this.btn_bereken.UseVisualStyleBackColor = true;
            this.btn_bereken.Click += new System.EventHandler(this.btn_bereken_Click);
            // 
            // lbl_DagBedrag
            // 
            this.lbl_DagBedrag.AutoSize = true;
            this.lbl_DagBedrag.Location = new System.Drawing.Point(141, 178);
            this.lbl_DagBedrag.Name = "lbl_DagBedrag";
            this.lbl_DagBedrag.Size = new System.Drawing.Size(64, 13);
            this.lbl_DagBedrag.TabIndex = 32;
            this.lbl_DagBedrag.Text = "Dag Bedrag";
            // 
            // tb_dagbedrag
            // 
            this.tb_dagbedrag.Location = new System.Drawing.Point(144, 194);
            this.tb_dagbedrag.Name = "tb_dagbedrag";
            this.tb_dagbedrag.ReadOnly = true;
            this.tb_dagbedrag.Size = new System.Drawing.Size(100, 20);
            this.tb_dagbedrag.TabIndex = 31;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(6, 28);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 33;
            // 
            // gb_gegevens
            // 
            this.gb_gegevens.Controls.Add(this.cb_EindMinuten);
            this.gb_gegevens.Controls.Add(this.lbl_EuroPerUur);
            this.gb_gegevens.Controls.Add(this.cb_EindUur);
            this.gb_gegevens.Controls.Add(this.lbl_urenGewerkt);
            this.gb_gegevens.Controls.Add(this.cb_BeginMinuten);
            this.gb_gegevens.Controls.Add(this.lbl_DagBedrag);
            this.gb_gegevens.Controls.Add(this.cb_BeginUur);
            this.gb_gegevens.Controls.Add(this.tb_dagbedrag);
            this.gb_gegevens.Controls.Add(this.btn_bereken);
            this.gb_gegevens.Controls.Add(this.lbl_BeginUur);
            this.gb_gegevens.Controls.Add(this.lbl_EindUue);
            this.gb_gegevens.Controls.Add(this.tb_EuroPerUur);
            this.gb_gegevens.Controls.Add(this.tb_werkuren);
            this.gb_gegevens.Location = new System.Drawing.Point(267, 29);
            this.gb_gegevens.Name = "gb_gegevens";
            this.gb_gegevens.Size = new System.Drawing.Size(250, 220);
            this.gb_gegevens.TabIndex = 34;
            this.gb_gegevens.TabStop = false;
            this.gb_gegevens.Text = "Gegevens";
            // 
            // lbl_EuroPerUur
            // 
            this.lbl_EuroPerUur.AutoSize = true;
            this.lbl_EuroPerUur.Location = new System.Drawing.Point(13, 114);
            this.lbl_EuroPerUur.Name = "lbl_EuroPerUur";
            this.lbl_EuroPerUur.Size = new System.Drawing.Size(35, 13);
            this.lbl_EuroPerUur.TabIndex = 33;
            this.lbl_EuroPerUur.Text = "€/Uur";
            // 
            // gb_WerkDag
            // 
            this.gb_WerkDag.Controls.Add(this.dateTimePicker1);
            this.gb_WerkDag.Controls.Add(this.cb_werkdag);
            this.gb_WerkDag.Location = new System.Drawing.Point(12, 29);
            this.gb_WerkDag.Name = "gb_WerkDag";
            this.gb_WerkDag.Size = new System.Drawing.Size(215, 100);
            this.gb_WerkDag.TabIndex = 35;
            this.gb_WerkDag.TabStop = false;
            this.gb_WerkDag.Text = "Werk Dag";
            // 
            // cb_BeginUur
            // 
            this.cb_BeginUur.FormatString = "t";
            this.cb_BeginUur.FormattingEnabled = true;
            this.cb_BeginUur.Location = new System.Drawing.Point(6, 48);
            this.cb_BeginUur.Name = "cb_BeginUur";
            this.cb_BeginUur.Size = new System.Drawing.Size(73, 21);
            this.cb_BeginUur.TabIndex = 36;
            this.cb_BeginUur.Text = "Uur";
            // 
            // cb_BeginMinuten
            // 
            this.cb_BeginMinuten.FormattingEnabled = true;
            this.cb_BeginMinuten.Location = new System.Drawing.Point(85, 48);
            this.cb_BeginMinuten.Name = "cb_BeginMinuten";
            this.cb_BeginMinuten.Size = new System.Drawing.Size(82, 21);
            this.cb_BeginMinuten.TabIndex = 37;
            this.cb_BeginMinuten.Text = "Minuten";
            // 
            // cb_EindUur
            // 
            this.cb_EindUur.FormatString = "t";
            this.cb_EindUur.FormattingEnabled = true;
            this.cb_EindUur.Location = new System.Drawing.Point(6, 89);
            this.cb_EindUur.Name = "cb_EindUur";
            this.cb_EindUur.Size = new System.Drawing.Size(73, 21);
            this.cb_EindUur.TabIndex = 38;
            this.cb_EindUur.Text = "Uur";
            // 
            // cb_EindMinuten
            // 
            this.cb_EindMinuten.FormattingEnabled = true;
            this.cb_EindMinuten.Location = new System.Drawing.Point(85, 89);
            this.cb_EindMinuten.Name = "cb_EindMinuten";
            this.cb_EindMinuten.Size = new System.Drawing.Size(82, 21);
            this.cb_EindMinuten.TabIndex = 39;
            this.cb_EindMinuten.Text = "Minuten";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 261);
            this.Controls.Add(this.gb_WerkDag);
            this.Controls.Add(this.gb_gegevens);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gb_gegevens.ResumeLayout(false);
            this.gb_gegevens.PerformLayout();
            this.gb_WerkDag.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox cb_werkdag;
        private System.Windows.Forms.Label lbl_BeginUur;
        private System.Windows.Forms.Label lbl_EindUue;
        private System.Windows.Forms.Label lbl_urenGewerkt;
        private System.Windows.Forms.TextBox tb_EuroPerUur;
        private System.Windows.Forms.Button btn_bereken;
        private System.Windows.Forms.TextBox tb_werkuren;
        private System.Windows.Forms.Label lbl_DagBedrag;
        private System.Windows.Forms.TextBox tb_dagbedrag;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox gb_gegevens;
        private System.Windows.Forms.Label lbl_EuroPerUur;
        private System.Windows.Forms.GroupBox gb_WerkDag;
        private System.Windows.Forms.ComboBox cb_BeginUur;
        private System.Windows.Forms.ComboBox cb_BeginMinuten;
        private System.Windows.Forms.ComboBox cb_EindMinuten;
        private System.Windows.Forms.ComboBox cb_EindUur;
    }
}

