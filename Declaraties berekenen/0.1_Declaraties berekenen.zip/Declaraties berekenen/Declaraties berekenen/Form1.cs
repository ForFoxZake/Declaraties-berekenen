﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Declaraties_berekenen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TimePicker_begin.Format = DateTimePickerFormat.Custom;
            TimePicker_begin.CustomFormat = "HH:mm";

            TimePicker_einde.Format = DateTimePickerFormat.Custom;
            TimePicker_einde.CustomFormat = "HH:mm";

            datePicker.Format = DateTimePickerFormat.Custom;
            datePicker.CustomFormat = "dd/MM/yyyy";
        }//form1

        private void btn_bereken_Click(object sender, EventArgs e)
        {
            DateTime nu = DateTime.Now;
            DateTime uur = nu.AddHours(2).AddMinutes(3);

            TimeSpan verschil = uur - nu;
            MessageBox.Show(Convert.ToString(verschil.Days));
            MessageBox.Show(Convert.ToString(verschil.Hours));
            MessageBox.Show(Convert.ToString(verschil.Minutes));


            /*
            //TimeSpan tijds_verschil = new TimeSpan;
            TimeSpan endTime = TimePicker_einde - TimePicker_begin;

            TimeSpan span = endTime.Subtract(startTime);
            Console.WriteLine("Time Difference (minutes): " + span.Minutes);
            Console.WriteLine("Time Difference (hours): " + span.Hours);
            Console.WriteLine("Time Difference (days): " + span.Days);
            */



            /*
            //Begin uren en minuten aan elkaar plakken
            int begin_uren = Convert.ToInt32(cb_BeginUur.SelectedItem);
            int begin_minuten= Convert.ToInt32(cb_BeginMinuten.SelectedItem);
            TimeSpan begin_tijd = TimeSpan.FromHours(begin_uren) + TimeSpan.FromMinutes(begin_minuten);
            string fromTimeString_begintijd = begin_tijd.ToString("hh':'mm");
            //MessageBox.Show("Begin tijd:" + fromTimeString_begintijd); //WERKT!!!

            //Eind uren en minuten aan elkaar plakken
            int eind_uren = Convert.ToInt32(cb_EindUur.SelectedItem);
            int eind_minuten = Convert.ToInt32(cb_EindMinuten.SelectedItem);
            TimeSpan eind_tijd = TimeSpan.FromHours(eind_uren) + TimeSpan.FromMinutes(eind_minuten);
            string fromTimeString_eindtijd = eind_tijd.ToString("hh':'mm");
            //MessageBox.Show("Eind tijd:" + fromTimeString_eindtijd); //WERKT!!!
            

            //Verschil Begin en Einduur berekenen
            TimeSpan verschil = eind_tijd - begin_tijd;
            tb_werkuren.Text = Convert.ToString(String.Format("{0}:{1}",verschil.Hours ,verschil.Minutes));

            //
            int dagbedrag = Convert.ToInt32(tb_werkuren.Text) * Convert.ToInt32(tb_EuroPerUur.Text);
            */
        }//btn_bereken_Click
    }
}
